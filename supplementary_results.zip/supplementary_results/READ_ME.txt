#####################################################################
#####################################################################
# THIS FILE BELONGS TO THE SUPPLEMENTARY MATERIAL PROVIDED WITH THE #
# ICIP 2016 PAPER "DEEP NEURAL NETWORKS UNDER STRESS".              #
#####################################################################
#####################################################################

Hello !

Thank you for downloading our stress framework.
Please feel free to contact me if you have any questions or comments
: micael.carvalho[at]lip6.fr

In this folder, we provide extra results for our experiments.

We also offer results for an additional experiment, which erases bits
from the binary representation of the numbers in the feature vectors.

In the Q-B experiment, we convert all single-precision floating-
point numbers to the double-precision format (from 32 bits to 64
bits). Then, we start erasing (setting to 0) the rightmost bits.

Until 50 bits are erased, we take steps of 5 bits at a time (i.e.,
we erase 5 bits, and then the next 5 bits, and so on). When we reach
50 erased bits, we start erasing them one by one.

We see that even a simple quantization of the binary representation
can efficiently compress the representation. In the beginning of the
experiment, we convert the single-precision floating-point to double
-precision numbers to facilitate some operations;
It is easy to see, however, that the initial single representation
would be even more compressed. Due to space constraints, we opted to
leave this experiment out of the paper.
